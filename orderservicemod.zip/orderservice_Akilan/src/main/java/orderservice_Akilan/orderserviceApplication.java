package orderservice_Akilan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class orderserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(orderserviceApplication.class, args);
	}

}
